# predict_nointerp_datefix_with_r2_scatter.py
"""
Script de validación para un modelo PINN (Physics-Informed Neural Network) 
entrenado para predecir la variable 'chlor_a' (concentración de clorofila).

Lee un conjunto de datos nuevos (NEW_DATA_CSV), calcula predicciones para 
todos los registros usando el modelo guardado (pesos y metadatos), y luego
filtra por una fecha específica (TARGET_DATE) para comparar visualmente
los valores reales (si existen) con los predichos.

Genera:
- Un archivo CSV con todas las predicciones globales.
- Un archivo CSV con las predicciones y valores reales de la fecha seleccionada.
- Un mapa (scatter) comparando real vs predicho para esa fecha.
- Un gráfico de paridad (scatter con R², MAE, RMSE) para la fecha seleccionada.
- Un gráfico de paridad global (si hay valores reales en todos los datos).
- Un gráfico adicional de R² global vs R² de la fecha seleccionada (aunque el código 
  no lo implementa completamente, se menciona en el encabezado; se incluye una 
  referencia en OUTPUT_R2_SCATTER pero no se genera realmente. Se ha dejado 
  preparado para una futura implementación).

El script asume que el modelo fue entrenado con una normalización específica
(escalado de entradas y estandarización de la variable objetivo) y que los
metadatos (límites, medias, desviaciones) están guardados en un archivo JSON.
"""

import os
import json
import re
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import tensorflow as tf
from datetime import datetime, timedelta
from sklearn.metrics import r2_score, mean_absolute_error, mean_squared_error

# ------------------------- CONFIGURACIÓN -------------------------
# Nombre de la variable objetivo (debe coincidir con el usado en el entrenamiento)


VAR_NAME = 'chlor_a'
#Directorio donde se encuentran los resultados del modelo (metadatos y pesos)
#MODEL_DIR = r"C:/Users/johan/Desktop/PINN VALENTINA/RESULTADOS_SEMANA/BASES_DE_DATOS_OUT_chlor_a"
MODEL_DIR = r"C:/Users/johan/Desktop/PINN VALENTINA/BASES_DE_DATOS_OUT_chlor_a"
# Archivo CSV de entrenamiento (se usa solo para obtener las escalas de entrada)
TRAIN_CSV = r"C:\Users\johan\Desktop\PINN VALENTINA\unidas_fecha.csv"
# Archivo CSV con los nuevos datos a validar
NEW_DATA_CSV = r"C:\Users\johan\Desktop\PINN VALENTINA\datos_validacion\Modis_semanal_2025\unidas_semanal_2025.csv"
# Directorio de salida para los resultados de validación
OUTPUT_DIR = os.path.join(MODEL_DIR, "validacion_simple")
os.makedirs(OUTPUT_DIR, exist_ok=True)

mes = '01'
# Nombres de archivos de salida
OUTPUT_PRED_CSV = os.path.join(OUTPUT_DIR, f"predicciones_usadas_para_mapa_{mes}.csv")
OUTPUT_MAP_PLOT = os.path.join(OUTPUT_DIR, f"heatmap_scatter_real_vs_pred_pointstyle_{mes}.png")
OUTPUT_PARITY_PLOT = os.path.join(OUTPUT_DIR, f"parity_scatter_with_r2_{mes}.png")
OUTPUT_PRED_CSV_GLOBAL = os.path.join(OUTPUT_DIR, f"predicciones_todos_los_datos_{mes}.csv")
OUTPUT_R2_SCATTER = os.path.join(OUTPUT_DIR, f"r2_scatter_global_vs_selected_{mes}.png")  # (aún no implementado)
# Nombres de columnas en los CSV (ajustar si es necesario)
col_lat = 'lat'
col_lon = 'lon'
col_time = 'Fecha'   # Puede ser fracción (0..1) o YYYYMMDD u otro formato
# Configuración de la fecha objetivo
TARGET_DATE = f'2025-{mes}-01'   # Fecha que se desea analizar (puede ser string, int YYYYMMDD, o tupla (año, mes, día))
TIME_TOL_DAYS = 0            # Tolerancia en días para selección (0 = fecha exacta)
# ----------------------------------------------------------------
def clean_numeric_string_simple(s):
    """
    Limpia y convierte a float una cadena que puede contener formatos numéricos
    problemáticos (puntos duplicados, comas como separador decimal, caracteres no numéricos).
    Parámetros:
        s : cualquier tipo (generalmente string o número)
    Retorna:
        float o np.nan si no se puede convertir.
    """
    if pd.isna(s):
        return np.nan
    if not isinstance(s, str):
        return s
    s = s.strip()
    # Si hay más de un punto, eliminar los puntos extras (deja solo el primero)
    if s.count('.') > 1:
        first = s.find('.')
        s = s[: first + 1] + s[first + 1:].replace('.', '')
    # Si hay coma y no hay punto, reemplazar coma por punto (separador decimal europeo)
    if (',' in s) and ('.' not in s):
        s = s.replace(',', '.')
    # Eliminar cualquier caracter que no sea dígito, punto, guión, e, E, + (notación científica)
    s = re.sub(r"[^\d\.\-eE\+]", "", s)
    try:
        return float(s)
    except:
        return np.nan
def latlon_to_xy(lat_arr, lon_arr, lat0, lon0):
    """
    Convierte coordenadas geográficas (lat, lon) a coordenadas cartesianas (x, y)
    usando una proyección equidistante simple (basada en radio terrestre).
    Parámetros:
        lat_arr, lon_arr : arrays de latitud y longitud en grados.
        lat0, lon0       : latitud y longitud de referencia (origen del sistema cartesiano).
    Retorna:
        x, y : arrays con coordenadas en metros.
    """
    R = 6371000.0  # Radio medio de la Tierra en metros
    lat_rad = np.deg2rad(np.array(lat_arr, dtype=float))
    lon_rad = np.deg2rad(np.array(lon_arr, dtype=float))
    lat0_rad = np.deg2rad(float(lat0))
    lon0_rad = np.deg2rad(float(lon0))
    x = R * (lon_rad - lon0_rad) * np.cos(lat0_rad)
    y = R * (lat_rad - lat0_rad)
    return x, y
def parse_target_date(value):
    """
    Convierte diferentes formatos de fecha a un objeto pd.Timestamp.
    Soporta: pd.Timestamp, tupla (año, mes, día), entero YYYYMMDD, string convertible.
    Parámetros:
        value : fecha en varios formatos posibles.
    Retorna:
        pd.Timestamp o pd.NaT si no se puede parsear.
    """
    if isinstance(value, pd.Timestamp):
        return value
    if isinstance(value, (tuple, list)) and len(value) >= 3:
        y, m, d = int(value[0]), int(value[1]), int(value[2])
        return pd.Timestamp(year=y, month=m, day=d)
    if isinstance(value, (int, float, np.integer, np.floating)):
        try:
            iv = int(value)
            if iv > 1e7:  # asume formato YYYYMMDD
                return pd.to_datetime(str(iv), format='%Y%m%d', errors='coerce')
        except Exception:
            pass
    try:
        return pd.to_datetime(value)
    except Exception:
        return pd.NaT
def construct_fecha_dt_from_components(df):
    """
    Intenta construir una columna datetime a partir de columnas 'Año', 'Mes', 'Día'.
    Parámetros:
        df : DataFrame que puede contener esas columnas.
    Retorna:
        Series de Timestamp si las columnas existen, None en caso contrario.
    """
    if {'Año', 'Mes', 'Día'}.issubset(df.columns):
        try:
            # Conversión vectorizada
            anos = df['Año'].astype(int)
            meses = df['Mes'].astype(int)
            dias = df['Día'].astype(int)
            return pd.to_datetime({'year': anos, 'month': meses, 'day': dias}, errors='coerce')
        except Exception:
            # Fallback: aplicar fila por fila
            def safe_dt(row):
                try:
                    y = int(row['Año'])
                    m = int(row['Mes'])
                    d = int(row['Día'])
                    return pd.Timestamp(year=y, month=m, day=d)
                except Exception:
                    return pd.NaT
            return df.apply(safe_dt, axis=1)
    return None
def construct_fecha_dt_from_fraction(df):
    """
    Intenta construir una columna datetime a partir de una columna 'Fecha' que contiene
    una fracción del año (0..1) y una columna 'Año' con el año correspondiente.
    Parámetros:
        df : DataFrame con columnas 'Fecha' (fracción) y 'Año'.
    Retorna:
        Series de Timestamp si es aplicable, None en caso contrario.
    """
    if 'Fecha' in df.columns and 'Año' in df.columns:
        frac = pd.to_numeric(df['Fecha'], errors='coerce')
        if frac.notna().any():
            mx = frac.max()
            mn = frac.min()
            # Si los valores están aproximadamente entre 0 y 1, asumimos fracción de año
            if (mn >= -0.1) and (mx <= 1.1):
                years = df['Año'].fillna(method='ffill').astype(int)
                days = (frac * 365).round().fillna(0).astype(int)
                fecha_list = []
                for y, d in zip(years.values, days.values):
                    try:
                        fecha_list.append(pd.Timestamp(year=int(y), month=1, day=1) + pd.Timedelta(days=int(d)))
                    except Exception:
                        fecha_list.append(pd.NaT)
                return pd.Series(fecha_list, index=df.index)
    return None
# ------------------------- CARGA DEL MODELO -------------------------
# Rutas de los archivos de metadatos y pesos
metadata_path = os.path.join(MODEL_DIR, f"model_{VAR_NAME}_metadata.json")
weights_path = os.path.join(MODEL_DIR, f"model_{VAR_NAME}_weights.npz")
# Cargar metadatos (JSON) y pesos (NPZ)
with open(metadata_path, 'r') as f:
    meta = json.load(f)
npz = np.load(weights_path, allow_pickle=True)
# Extraer pesos y biases de las capas del modelo
nn_weights = []
nn_biases = []
i = 0
while f'weight_{i}' in npz:
    nn_weights.append(npz[f'weight_{i}'].astype(np.float32))
    nn_biases.append(npz[f'bias_{i}'].astype(np.float32))
    i += 1
if len(nn_weights) == 0:
    raise ValueError("No se encontraron pesos (weight_i, bias_i) en el .npz")
# Escala de salida (si el modelo la usó, por defecto 1.0)
out_scale = float(npz.get('out_scale', 1.0))
# Parámetros de normalización del modelo
layers = meta['layers']               # Arquitectura de la red
lb = np.array(meta['lb'], dtype=np.float32)   # Límite inferior para escalado de entradas
ub = np.array(meta['ub'], dtype=np.float32)   # Límite superior para escalado de entradas
y_mean = float(meta['y_mean'])        # Media de la variable objetivo (en espacio log)
y_std = float(meta['y_std'])           # Desviación estándar de la variable objetivo (en espacio log)
lat0, lon0 = meta['lat0'], meta['lon0']   # Coordenadas de referencia para proyección cartesiana
# Definición de la clase que encapsula el modelo PINN para predicción
class SimplePINN:
    """
    Clase para cargar y ejecutar un modelo PINN pre-entrenado.
    Realiza el escalado de las entradas y la desnormalización de la salida.
    """
    def __init__(self, layers, lb, ub, weights, biases, out_scale=1.0):
        """
        Inicializa el modelo con los límites de escalado y los pesos.
        Parámetros:
            layers    : lista con el número de neuronas por capa.
            lb, ub    : arrays de límites inferior y superior para las entradas.
            weights   : lista de matrices de pesos (W) por capa.
            biases    : lista de vectores de bias por capa.
            out_scale : factor de escala adicional para la salida (útil si el modelo fue entrenado con él).
        """
        self.lb = tf.constant(lb, dtype=tf.float32)
        self.ub = tf.constant(ub, dtype=tf.float32)
        self.layers = layers
        self.W = []
        self.b = []
        for w, bb in zip(weights, biases):
            self.W.append(tf.Variable(w, trainable=False, dtype=tf.float32))
            bb2 = np.atleast_2d(bb).astype(np.float32)   # Asegurar forma (1, n_neurons)
            self.b.append(tf.Variable(bb2, trainable=False, dtype=tf.float32))
        self.out_scale = tf.Variable(out_scale, trainable=False, dtype=tf.float32)
    def neural_net(self, X):
        """
        Propagación hacia adelante con escalado de entrada y activaciones tanh.
        """
        # Escalar X al rango [-1, 1] usando los límites lb, ub
        H = 2.0 * (X - self.lb) / (self.ub - self.lb + 1e-12) - 1.0
        # Capas ocultas con tanh
        for W, b in zip(self.W[:-1], self.b[:-1]):
            H = tf.tanh(tf.matmul(H, W) + b)
        # Capa de salida (lineal)
        out = tf.matmul(H, self.W[-1]) + self.b[-1]
        return self.out_scale * out
    def predict(self, X_np):
        """
        Método público para predecir a partir de un array numpy.
        Parámetros:
            X_np : array de forma (n_muestras, 3) con columnas [x, y, t].
        Retorna:
            array con las predicciones (ya en espacio original, pero sin deshacer el log,
            es decir, salida del modelo en espacio logarítmico, que luego será transformada).
        """
        X_np = np.asarray(X_np, dtype=np.float32)
        X_tf = tf.convert_to_tensor(X_np, dtype=tf.float32)
        return self.neural_net(X_tf).numpy().ravel()
# Instanciar el modelo
model = SimplePINN(layers, lb, ub, nn_weights, nn_biases, out_scale)
print("Modelo cargado.")
# ------------------------- CÁLCULO DE ESCALAS DE ENTRADA DESDE TRAIN -------------------------
# Leer datos de entrenamiento para obtener los rangos de x, y, t (en metros y días)
df_train = pd.read_csv(TRAIN_CSV, encoding='utf-8', low_memory=False)
df_train.columns = [c.strip() for c in df_train.columns]
# Limpiar columnas que puedan tener formato numérico incorrecto
for c in df_train.columns:
    if df_train[c].dtype == object:
        df_train[c] = df_train[c].apply(clean_numeric_string_simple)
# Intentar construir la columna de fecha (datetime) a partir de diferentes formatos
fecha_dt_train = construct_fecha_dt_from_components(df_train)
if fecha_dt_train is None or fecha_dt_train.isna().all():
    fecha_dt_train = construct_fecha_dt_from_fraction(df_train)
if fecha_dt_train is None or fecha_dt_train.isna().all():
    fecha_dt_train = pd.to_datetime(df_train[col_time], errors='coerce')
df_train['Fecha_dt'] = fecha_dt_train
if df_train['Fecha_dt'].isna().all():
    raise ValueError("No se pudo parsear 'Fecha' en TRAIN_CSV. Revisa Año/Mes/Día o el campo Fecha.")
# Eliminar filas sin coordenadas o fecha válida
df_train = df_train.dropna(subset=[col_lat, col_lon, 'Fecha_dt']).copy()
# Fecha de referencia para convertir fechas a días (mínima fecha en entrenamiento)
t_ref = df_train['Fecha_dt'].min()
# Convertir lat/lon a coordenadas cartesianas (x,y) usando el punto de referencia del modelo
x_tr, y_tr = latlon_to_xy(df_train[col_lat].values, df_train[col_lon].values, lat0, lon0)
# Convertir fecha a días transcurridos desde t_ref
t_tr = (df_train['Fecha_dt'] - t_ref).dt.days.astype(float).values
# Apilar para obtener matriz de entrada cruda (sin escalar)
X_raw_train = np.vstack([x_tr, y_tr, t_tr]).T
# Guardar los valores mínimos y máximos de cada variable (se usarán para escalar los nuevos datos)
X_min = X_raw_train.min(axis=0)
X_max = X_raw_train.max(axis=0)
# ------------------------- LECTURA Y PROCESAMIENTO DE NUEVOS DATOS -------------------------
df_new = pd.read_csv(NEW_DATA_CSV, encoding='utf-8', low_memory=False)
df_new.columns = [c.strip() for c in df_new.columns]
for c in df_new.columns:
    if df_new[c].dtype == object:
        df_new[c] = df_new[c].apply(clean_numeric_string_simple)
# Intentar construir fechas con los mismos métodos que en entrenamiento
fecha_dt_new = construct_fecha_dt_from_components(df_new)
if fecha_dt_new is None or fecha_dt_new.isna().all():
    fecha_dt_new = construct_fecha_dt_from_fraction(df_new)
if fecha_dt_new is None or fecha_dt_new.isna().all():
    fecha_dt_new = pd.to_datetime(df_new[col_time], errors='coerce')
df_new['Fecha_dt'] = fecha_dt_new
if df_new['Fecha_dt'].isna().all():
    raise ValueError("No se pudo parsear 'Fecha' en NEW_DATA_CSV. Revisa Año/Mes/Día o el campo Fecha.")
# Eliminar filas sin coordenadas o fecha
df_new = df_new.dropna(subset=[col_lat, col_lon, 'Fecha_dt']).copy()
# ------------------------- PREDICCIONES GLOBALES (TODOS LOS REGISTROS) -------------------------
# Convertir coordenadas y fechas a x,y,t (usando la misma referencia t_ref del entrenamiento)
x_all, y_all = latlon_to_xy(df_new[col_lat].values, df_new[col_lon].values, lat0, lon0)
t_all = (df_new['Fecha_dt'] - t_ref).dt.days.astype(float).values
X_raw_all = np.vstack([x_all, y_all, t_all]).T
# Escalar las entradas usando los rangos del entrenamiento
X_scaled_all = (X_raw_all - X_min) / (X_max - X_min + 1e-12)
# Predecir con el modelo (salida en espacio logarítmico normalizado)
pred_scaled_all = model.predict(X_scaled_all)
# Deshacer la estandarización: pasar de (y - y_mean)/y_std a y_log
pred_logged_all = pred_scaled_all * y_std + y_mean
# Transformar inversa de log1p (ya que la variable fue transformada con np.log1p en entrenamiento)
pred_original_all = np.expm1(pred_logged_all)
# Agregar las predicciones al DataFrame
df_new = df_new.copy()
df_new['pred_' + VAR_NAME] = pred_original_all
# Si existen valores reales en los nuevos datos, calcular métricas globales
global_metrics_available = VAR_NAME in df_new.columns and df_new[VAR_NAME].notna().any()
if global_metrics_available:
    mask_real_global = df_new[VAR_NAME].notna()
    y_true_global = df_new.loc[mask_real_global, VAR_NAME].astype(float).values
    y_pred_global = df_new.loc[mask_real_global, 'pred_' + VAR_NAME].astype(float).values
    r2_global = r2_score(y_true_global, y_pred_global) if len(y_true_global) > 1 else float('nan')
    mae_global = mean_absolute_error(y_true_global, y_pred_global)
    rmse_global = np.sqrt(mean_squared_error(y_true_global, y_pred_global))
    print("\n--- Métricas GLOBALES ---")
    print(f"N_global = {len(y_true_global)}")
    print(f"R² global  = {r2_global:.4f}")
    print(f"MAE global = {mae_global:.4f}")
    print(f"RMSE global= {rmse_global:.4f}")
    # Calcular residual (diferencia) para cada punto con valor real
    df_new['residual_' + VAR_NAME] = np.where(df_new[VAR_NAME].notna(),
                                               df_new[VAR_NAME].astype(float) - df_new['pred_' + VAR_NAME].astype(float),
                                               np.nan)
else:
    r2_global = np.nan
    print("No hay valores reales en NEW_DATA_CSV para calcular métricas globales.")
# Guardar CSV con todas las predicciones (incluyendo las fechas no seleccionadas)
df_new.to_csv(OUTPUT_PRED_CSV_GLOBAL, index=False)
print(f"CSV con TODAS las predicciones guardado en: {OUTPUT_PRED_CSV_GLOBAL}")
# ------------------------- SELECCIÓN POR FECHA OBJETIVO -------------------------
# Convertir la fecha objetivo a Timestamp
TARGET_DATE_dt = parse_target_date(TARGET_DATE)
if pd.isna(TARGET_DATE_dt):
    raise ValueError("No se pudo parsear TARGET_DATE. Pasa '2025-01-01', 20250101, o (2025,1,1).")
# Filtrar filas cuya fecha esté dentro de la tolerancia
if TIME_TOL_DAYS == 0:
    time_mask = df_new['Fecha_dt'].dt.normalize() == TARGET_DATE_dt.normalize()
else:
    days_diff = (df_new['Fecha_dt'] - TARGET_DATE_dt).abs().dt.days
    time_mask = days_diff <= TIME_TOL_DAYS
df_time = df_new[time_mask].copy()
if df_time.shape[0] == 0:
    # Si no hay coincidencias exactas, tomar la fecha más cercana
    diffs = (df_new['Fecha_dt'] - TARGET_DATE_dt).abs().dt.days
    idx = diffs.idxmin()
    closest_date = df_new.loc[idx, 'Fecha_dt']
    print(f"No hay filas exactas en fecha {TARGET_DATE_dt.date()}. Usando fecha más cercana: {closest_date.date()}")
    df_time = df_new[df_new['Fecha_dt'] == closest_date].copy()
# Verificar que exista la columna objetivo
if VAR_NAME not in df_time.columns:
    raise ValueError(f"La columna objetivo '{VAR_NAME}' no está en NEW_DATA_CSV para la fecha seleccionada.")
# Quedarse solo con los puntos que tienen valor real (no NaN)
df_eval = df_time[df_time[VAR_NAME].notna()].copy()
if df_eval.shape[0] == 0:
    print("No hay puntos con valor real (no NaN) para la variable en la fecha seleccionada. Abortando.")
    raise SystemExit()
# Preparar columnas útiles
df_eval = df_eval.copy()
df_eval['Fecha_str'] = df_eval['Fecha_dt'].dt.strftime('%d-%m-%Y')
fecha_titulo_str = df_eval['Fecha_dt'].dt.strftime('%d-%m-%Y').unique()[0]
# Asegurar tipos numéricos
df_eval['pred_' + VAR_NAME] = df_eval['pred_' + VAR_NAME].astype(float)
df_eval['true_' + VAR_NAME] = df_eval[VAR_NAME].astype(float)
df_eval['residual'] = df_eval['true_' + VAR_NAME] - df_eval['pred_' + VAR_NAME]
# Calcular métricas para la fecha seleccionada
y_true = df_eval['true_' + VAR_NAME].values
y_pred = df_eval['pred_' + VAR_NAME].values
r2 = r2_score(y_true, y_pred) if len(y_true) > 1 else float('nan')
mae = mean_absolute_error(y_true, y_pred)
rmse = np.sqrt(mean_squared_error(y_true, y_pred))
print("\n--- Métricas para la fecha seleccionada ---")
print(f"Fecha = {fecha_titulo_str}")
print(f"N = {len(y_true)}")
print(f"R²  = {r2:.4f}")
print(f"MAE = {mae:.4f}")
print(f"RMSE= {rmse:.4f}")
# Guardar CSV con los datos de la fecha seleccionada (solo columnas relevantes)
cols_out = [col_lat, col_lon, col_time, 'Fecha_str', 'true_' + VAR_NAME, 'pred_' + VAR_NAME, 'residual']
df_eval[cols_out].to_csv(OUTPUT_PRED_CSV, index=False)
print(f"CSV con datos reales/predichos (fecha seleccionada) guardado en: {OUTPUT_PRED_CSV}")
# ------------------------- GENERACIÓN DE MAPA SCATTER -------------------------
# Se crean dos subplots: izquierda valores reales, derecha valores predichos
s_mark = 40          # Tamaño de los marcadores
alpha_mark = 0.8     # Transparencia
# Definir rango común de colores para ambos gráficos
vmin = min(df_eval['true_' + VAR_NAME].min(), df_eval['pred_' + VAR_NAME].min())
vmax = max(df_eval['true_' + VAR_NAME].max(), df_eval['pred_' + VAR_NAME].max())
fig, axs = plt.subplots(1, 2, figsize=(12, 5), constrained_layout=True)
# Gráfico de valores reales
sc0 = axs[0].scatter(df_eval[col_lon], df_eval[col_lat],
                     c=df_eval['true_' + VAR_NAME], s=s_mark, cmap='jet',
                     vmin=vmin, vmax=vmax, alpha=alpha_mark, edgecolors='none')
axs[0].set_title(f"Real {VAR_NAME} (fecha {fecha_titulo_str})")
axs[0].set_xlabel('Lon')
axs[0].set_ylabel('Lat')
plt.colorbar(sc0, ax=axs[0], label=VAR_NAME)
# Gráfico de valores predichos
sc1 = axs[1].scatter(df_eval[col_lon], df_eval[col_lat],
                     c=df_eval['pred_' + VAR_NAME], s=s_mark, cmap='jet',
                     vmin=vmin, vmax=vmax, alpha=alpha_mark, edgecolors='none')
axs[1].set_title(f"Predicho {VAR_NAME} (fecha {fecha_titulo_str})")
axs[1].set_xlabel('Lon')
axs[1].set_ylabel('Lat')
plt.colorbar(sc1, ax=axs[1], label=VAR_NAME)
plt.suptitle(f"Comparación real vs predicho — fecha {fecha_titulo_str} — R²={r2:.3f}  N={len(y_true)}", fontsize=11)
plt.savefig(OUTPUT_MAP_PLOT, dpi=150)
plt.close()
print(f"Mapa scatter guardado en: {OUTPUT_MAP_PLOT}")
# ------------------------- GRÁFICO DE PARIDAD (OBSERVADO VS PREDICHO) PARA LA FECHA SELECCIONADA -------------------------
plt.figure(figsize=(6, 6))
plt.scatter(y_true, y_pred, s=20, alpha=0.6, edgecolors='k', linewidths=0.3)
# Línea 1:1 (identidad)
minv = min(np.min(y_true), np.min(y_pred))
maxv = max(np.max(y_true), np.max(y_pred))
plt.plot([minv, maxv], [minv, maxv], 'k--', linewidth=1, label='1:1')
# Línea de regresión lineal (ajuste por mínimos cuadrados)
if len(y_true) >= 2:
    coef = np.polyfit(y_true, y_pred, 1)
    a, b = coef
    x_line = np.linspace(minv, maxv, 100)
    y_line = a * x_line + b
    plt.plot(x_line, y_line, 'r-', linewidth=1.5, label=f'Ajuste: y={a:.2f}x+{b:.2f}')
plt.xlabel('Observado (true)')
plt.ylabel('Predicho (pred)')
plt.title(f'Paridad — {VAR_NAME} (fecha {fecha_titulo_str})')
plt.legend(loc='best')
# Cuadro de texto con métricas
metric_text = f"R² = {r2:.3f}\nMAE = {mae:.3f}\nRMSE = {rmse:.3f}\nN = {len(y_true)}"
plt.gca().text(0.05, 0.7, metric_text, transform=plt.gca().transAxes,
               fontsize=10, verticalalignment='top',
               bbox=dict(boxstyle="round,pad=0.4", facecolor="white", alpha=0.8))
plt.grid(True, linestyle='--', alpha=0.4)
plt.tight_layout()
plt.savefig(OUTPUT_PARITY_PLOT, dpi=150)
plt.close()
print(f"Grafico de paridad (scatter con R²) guardado en: {OUTPUT_PARITY_PLOT}")
# ------------------------- GRÁFICO DE PARIDAD GLOBAL (SI HAY DATOS) -------------------------
if global_metrics_available and len(y_true_global) > 1:
    plt.figure(figsize=(6, 6))
    plt.scatter(y_true_global, y_pred_global,
                s=20, alpha=0.6,
                edgecolors='k', linewidths=0.3)
    minv_g = min(np.min(y_true_global), np.min(y_pred_global))
    maxv_g = max(np.max(y_true_global), np.max(y_pred_global))
    # Línea 1:1
    plt.plot([minv_g, maxv_g], [minv_g, maxv_g],
             'k--', linewidth=1, label='1:1')
    # Línea de regresión
    coef_g = np.polyfit(y_true_global, y_pred_global, 1)
    a_g, b_g = coef_g
    x_line_g = np.linspace(minv_g, maxv_g, 200)
    y_line_g = a_g * x_line_g + b_g
    plt.plot(x_line_g, y_line_g,
             'r-', linewidth=1.5,
             label=f'Ajuste: y={a_g:.2f}x+{b_g:.2f}')
    plt.xlabel('Observado (true)')
    plt.ylabel('Predicho (pred)')
    plt.title(f'Paridad GLOBAL — {VAR_NAME}')
    plt.legend(loc='best')
    metric_text_g = (
        f"R² = {r2_global:.3f}\n"
        f"MAE = {mae_global:.3f}\n"
        f"RMSE = {rmse_global:.3f}\n"
        f"N = {len(y_true_global)}"
    )
    plt.gca().text(0.05, 0.7, metric_text_g,
                   transform=plt.gca().transAxes,
                   fontsize=10,
                   verticalalignment='top',
                   bbox=dict(boxstyle="round,pad=0.4",
                             facecolor="white", alpha=0.8))
    plt.grid(True, linestyle='--', alpha=0.4)
    plt.tight_layout()
    OUTPUT_PARITY_GLOBAL = os.path.join(OUTPUT_DIR, "parity_scatter_GLOBAL.png")
    plt.savefig(OUTPUT_PARITY_GLOBAL, dpi=150)
    plt.close()
    print(f"Grafico de paridad GLOBAL guardado en: {OUTPUT_PARITY_GLOBAL}")
# ------------------------- RESUMEN FINAL -------------------------
print("\nResumen final:")
if global_metrics_available:
    print(f"R² global (todos los datos con valor real): {r2_global:.4f}")
else:
    print("R² global: NA")
print(f"R² (fecha seleccionada {fecha_titulo_str}): {r2:.4f}")
print("Archivos generados:")
print(f"- Predicciones globales: {OUTPUT_PRED_CSV_GLOBAL}")
print(f"- Predicciones usadas para mapa (fecha seleccionada): {OUTPUT_PRED_CSV}")
print(f"- Mapa scatter: {OUTPUT_MAP_PLOT}")
print(f"- Parity plot: {OUTPUT_PARITY_PLOT}")
print(f"- R² scatter (pendiente): {OUTPUT_R2_SCATTER}")   # Nota: el gráfico de R² global vs fecha no se genera aún
print("Proceso finalizado.")